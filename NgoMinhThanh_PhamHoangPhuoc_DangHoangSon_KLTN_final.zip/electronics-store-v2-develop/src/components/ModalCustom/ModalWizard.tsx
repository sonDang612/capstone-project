import React from "react";

const ModalWizard = () => {
  return <div>ModalWizard</div>;
};

export default ModalWizard;
