export type Coupon = {
  _id: string;
  name: string;
  expiry: Date;
  discount: number;
  quantity: number;
};
