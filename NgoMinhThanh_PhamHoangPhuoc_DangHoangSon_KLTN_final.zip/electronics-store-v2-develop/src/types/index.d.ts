/* eslint-disable no-var */
/* eslint-disable vars-on-top */

declare global {
  var FB: any;
  interface Window {
    fbAsyncInit: any;
  }
}
export {};
