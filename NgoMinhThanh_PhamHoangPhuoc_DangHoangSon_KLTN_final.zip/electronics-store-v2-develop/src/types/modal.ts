export type Modal = {
  visible: boolean;
  head: string;
  subHead: string;
  button: string;
  createAccount: string;
  successful: boolean;
};
