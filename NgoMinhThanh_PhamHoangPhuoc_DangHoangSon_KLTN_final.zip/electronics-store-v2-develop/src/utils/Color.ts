export const COLOR: any = {
  0: "magenta",
  1: "red",
  2: "volcano",
  3: "orange",
  4: "gold",
  5: "lime",
  6: "green",
  7: "cyan",
  8: "blue",
  9: "geekblue",
  10: "purple",
  11: "warning",
};
